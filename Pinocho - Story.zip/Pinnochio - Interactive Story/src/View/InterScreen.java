package View;

public class InterScreen {

	public InterScreen() {

	}

}
