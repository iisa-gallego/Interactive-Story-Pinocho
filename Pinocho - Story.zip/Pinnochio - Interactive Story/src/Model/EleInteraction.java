package Model;

public class EleInteraction {

	public EleInteraction() {
		// TODO Auto-generated constructor stub
	}

}
