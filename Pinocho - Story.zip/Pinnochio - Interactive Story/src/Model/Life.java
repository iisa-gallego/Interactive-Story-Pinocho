package Model;

public class Life {

	public Life() {
		// TODO Auto-generated constructor stub
	}

}
