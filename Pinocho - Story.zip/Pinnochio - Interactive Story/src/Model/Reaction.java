package Model;

public class Reaction {

	public Reaction() {
		// TODO Auto-generated constructor stub
	}

}
