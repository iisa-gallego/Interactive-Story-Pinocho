package Model;

public class Magic {

	public Magic() {
		// TODO Auto-generated constructor stub
	}

}
