package Model;

public class Book {

	public Book() {
		// TODO Auto-generated constructor stub
	}

}
