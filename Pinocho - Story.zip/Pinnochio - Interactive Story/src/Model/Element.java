package Model;

import processing.core.PApplet;

public abstract class Element {
	protected PApplet app;
	protected int posX, posY;
}
